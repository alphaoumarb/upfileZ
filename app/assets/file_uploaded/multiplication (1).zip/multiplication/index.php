
        <!-- Block calcul mental -->
        <section id="table-calcul" class="bg-1 w100p mt-10 p-10 flex f-wrap j-center ac-f-start">
            <h3 class="txt-center h40 lh40 montserrat bg-0 color-1 fs-2 mb-10 w100p">Calcul mental</h3>
            <div class="w100p mb-30">
                <form id="form-select-calcul" name="form-select-calcul" class="w33p center" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <select name="select-table-calcul" id="select-table-calcul" class="w100p p-10 b-2 bcolor-0 bg-1 color-0 montserrat fs-1-4 mb-10">
                        <option value="">Sélectionnez</option>
<?php                   for($i=1; $i <= 10; $i++){ ?>
                            <option value="<?php echo $i ?>">Table des <?php echo $i; ?></option>
<?php                   } ?>                        
                    </select>
                    <button type="submit" id="submit-select-calcul" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-select-calcul">Choisir</button>
                </form>
            </div>
            <div class="w100p">
                <div id="calcul"></div>/*
                <form id="form-response-calcul" name="form-response-calcul" class="w33p center" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <input type="text" id="response-calcul" name="response-calcul" class="w100p p-10 b-2 bcolor-0 montserrat fs-1-4 mb-10" value="">
                    <button type="submit" id="submit-response-calcul" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-response-calcul">Répondre</button>
                </form>
                <div id="block-reponse-calcul"></div>
            </div>
        </section>
    </main>
    <footer class="bg-0 h100 w100p txt-center lh100">
        <p class="montserrat fs-3 color-1">@Khylick - 2018</p>
    </footer>
    <script src="./js/script.js"></script>
</body>
</html>