<?php

if(isset($_GET['checksValues'])){ // Traitement du formulaire du choix par checkboxes. 
    $checkboxes = explode(',', $_GET['checksValues']); // On transforme les valeurs reçues sous la forme d'une chaine de caractère (x, y, z, ...) en tableau $checkbox = array(x, y, z, ...)
    $retour = '';//html kon renvoie fonction ajax

    foreach($checkboxes as $checkbox){ // On construit nos tables de multiplications sous forme de liste
        $retour .= '<ul class="w30p txt-center mb-10 p-10 bcolor-0 b-3">';

        for($i = 1; $i <= 10; $i++){
            $retour .= '<li class="color-0 fs-1-6 montserrat">' . $i . ' x ' . $checkbox . ' = ' . ($i * $checkbox) . '</li>';
        }

        $retour .= '</ul>';
    }

    echo $retour; // On renvoie le HTML.

} else if(isset($_GET['selectedValue'])){ // Traitement du formulaire du choix par select.
    $value = intval($_GET['selectedValue']);
    $retour = '<ul class="w30p txt-center mb-10 p-10 bcolor-0 b-3">';

    for($i = 1; $i <= 10; $i++){
        $retour .= '<li class="color-0 fs-1-6 montserrat">' . $i . ' x ' . $value . ' = ' . ($i * $value) . '</li>'/*repetition kon peut compressé dans une fonction*/;
    }

    $retour .= '</ul>';

    echo $retour; // On renvoie le HTML.

} else if(isset($_GET['selectedValueCalcul'])){ // Traitement du premier formulaire du calcul mental.
    $value = intval($_GET['selectedValueCalcul']);
    $random = rand(1, 10);

    $retour = '<p id="question-calcul" data-value="' .$value. '" data-random="' .$random. '" class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p">Combien font : ' .$random. ' x ' .$value. ' ?</p>';

    echo $retour; // On renvoie le HTML.

} else if(isset($_GET['responseCalcul']) && isset($_GET['goodResponse'])){ // Traitement du second formulaire du calcul mental.
    $responseCalcul = intval($_GET['responseCalcul']);
    $goodResponse = intval($_GET['goodResponse']);

    if($goodResponse == $responseCalcul){ // Si la saisie de l'utilisateur est égale au calcul réalisé
        $retour = '<p class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p alert alert-error">Bravo ! Vous êtes trop une bête en calcul !</p>';
    } else { // Sinon
        $retour = '<p class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p alert alert-error">Ah ouais ? Sacré niveau quand même...</p>';
    }

    echo $retour; // On renvoie le HTML.

}