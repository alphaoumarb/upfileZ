// On stocke tous les boutons dans des variables
var submitChecks = document.getElementById('submit-checks');
var submitSelect = document.getElementById('submit-select');
var submitSelectCalcul = document.getElementById('submit-select-calcul');
var submitResponseCalcul = document.getElementById('submit-response-calcul');

// On ajoute un listener sur le bouton du formulaire du choix par checkboxes.
submitChecks.addEventListener('click', function(e){
    var checkTables = document.getElementsByClassName('checkbox'); // On stocke toutes les checkboxes.
    var tables = new Array();

    for(var i = 0; i < checkTables.length; i++){ // On boucle sur toutes les checkboxes
        if(checkTables[i].checked){ // Si la checkbox est cochée...
            tables.push(checkTables[i].value); // ...on ajoute sa valeur au tableau 'tables'
        }
    }

    if(tables.length > 0){ // Si le tableau 'table' a au moins 1 index, donc qu'au moins une checkbox est cochée
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("block-reponse-checks"/*div creer pour bloc réponse*/).innerHTML = this.responseText; // On affiche le HTML que nous renvoie le fichier 'traitement.ajax.php'
            }
        };
        
        xmlhttp.open("GET", "./ajax/traitement.ajax.php?checksValues=" + tables, true); // On envoie dans $_GET['checkValues'] au fichier 'traitement.ajax.php' le tableau 'table'
        xmlhttp.send();
    } else { // Si aucune checkbox n'est cochée, on affiche un message d'erreur.
        document.getElementById("block-reponse-checks").innerHTML = '<p class="mt-10 fs-1-6 montserrat txt-center w100p alert alert-error">Veuillez selectionner au moins une table.</p>';
    }

    e.preventDefault();

});

// On ajoute un listener sur le bouton du formulaire du choix par select.
submitSelect.addEventListener('click', function(e){
    var selectedTable = document.getElementById('select-table'); // On récupère le select associé au bouton 'submitSelect'...
    var selectedValue = parseInt(selectedTable.value); // ...et on récupère sa valeur.

    if(selectedValue > 0){ // Si cette valeur est supérieure à 0
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function(){
            if (this.readyState == 4 && this.status == 200) {
                var blockResponse = document.getElementById('block-reponse-select');
                blockResponse.innerHTML = this.responseText; // On affiche le HTML que nous renvoie le fichier 'traitement.ajax.php' dans l'élément 'blockResponse'
            }
        };
        
        xmlhttp.open("GET", "./ajax/traitement.ajax.php?selectedValue=" + selectedValue, true); // On envoie dans $_GET['selectedValue'] au fichier 'traitement.ajax.php' la valeur du select
        xmlhttp.send();
    } else { // Si aucune table n'a été sélectionnée, on affiche un message d'erreur.
        document.getElementById('block-reponse-select').innerHTML = '<p class="mt-10 fs-1-6 montserrat txt-center w100p alert alert-error">Veuillez selectionner une table.</p>';
    }

    e.preventDefault();
});

// On ajoute un listener sur le bouton du premier formulaire du calcul mental.
submitSelectCalcul.addEventListener('click', function(e){
    var selectedTableCalcul = document.getElementById('select-table-calcul'); // On récupère le select associé au bouton 'submitSelectCalcul'...
    var selectedValueCalcul = parseInt(selectedTableCalcul.value); // ...et on récupère sa valeur.

    if(selectedValueCalcul > 0){ // Si cette valeur est supérieur à 0
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function(){
            if (this.readyState == 4 && this.status == 200) {
                var blockQuestionCalcul = document.getElementById('calcul');
                blockQuestionCalcul.innerHTML = this.responseText; // On affiche le HTML que nous renvoie le fichier 'traitement.ajax.php' dans l'élément 'blockQuestionCalcul'
            }
        };
        
        xmlhttp.open("GET", "./ajax/traitement.ajax.php?selectedValueCalcul=" + selectedValueCalcul, true); // On envoie dans $_GET['selectedValueCalcul] au fichier 'traitement.ajax.php' la valeur du select
        xmlhttp.send();    
    } else { // Si aucune table n'a été sélectionnée, on affiche un message d'erreur.
        document.getElementById('calcul').innerHTML = '<p class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p alert alert-error">Veuillez selectionner une table.</p>';
    }

    e.preventDefault();
});


// On ajoute un listener sur le bouton du second formulaire du calcul mental.
submitResponseCalcul.addEventListener('click', function(e){
    var inputResponseCalcul = document.getElementById('response-calcul'); // On récupère l'élément input associé au bouton 'submitResponseCalcul'...
    var responseCalcul = inputResponseCalcul.value; // ...et on récupère la valeur saisie.
    var blockQuestionCalcul = document.getElementById('question-calcul'); // On récupère aussi le paragraphe généré suite au clic sur le bouton 'submitSelectCalcul' (ligne 60 à 80)

    if(responseCalcul != '' && blockQuestionCalcul != null){ // Si l'utilisateur a bien saisie une valeur et que le paragraphe 'blockQuestionCalcul' existe
        var value1 = blockQuestionCalcul.getAttribute('data-value'); // On récupère la valeur de son attribut data-value
        var value2 = blockQuestionCalcul.getAttribute('data-random'); // On récupère la valeur de son attribut data-random

        var goodResponse = value1 * value2;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function(){
            if (this.readyState == 4 && this.status == 200) {
                var blockResponseCalcul = document.getElementById('block-reponse-calcul')
                blockResponseCalcul.innerHTML = this.responseText; // On affiche le HTML que nous renvoie le fichier 'traitement.ajax.php' dans l'élément 'blockQuestionCalcul'
            }
        };
        
        xmlhttp.open("GET", "./ajax/traitement.ajax.php?responseCalcul=" + responseCalcul + '&goodResponse=' + goodResponse, true); // On envoie dans $_GET['selectedValueCalcul] au fichier 'traitement.ajax.php' la valeur du select
        xmlhttp.send();
        
    } else { // Si l'utilisateur n'a rien saisie ou si le paragraphe 'blockQuestionCalcul' n'existe pas
        if(blockQuestionCalcul == null){ // Si le paragraphe 'blockQuestionCalcul' n'existe pas
            document.getElementById('block-reponse-calcul').innerHTML = '<p class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p alert alert-error">On ne vous a pas demander de calcul.</p>';
        } else if(responseCalcul == ''){ // Si l'utilisateur n'a rien saisi.
            document.getElementById('block-reponse-calcul').innerHTML = '<p class="mt-10 mb-10 fs-1-6 montserrat txt-center w100p alert alert-error">Veuillez saisirune réponse valide.</p>';
        } 
    }

    e.preventDefault();
    
});