<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Multiplications</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link href="https://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body class="flex f-wrap f-column mh100v">
    <header class="bg-0 h100 w100p txt-center lh100">
        <h1 class="montserrat fs-4 color-1">Tables de Multiplication</h1>
    </header>
    <main class="grow flex f-wrap space-between m-10">

        <!-- Block Table aléatoire -->
        <section id="table-aleatoire" class="bg-1 w33p p-10 flex f-wrap j-center ac-f-start">
            <h3 class="txt-center h40 lh40 montserrat bg-0 color-1 fs-2 mb-10 w100p">Table aléatoire</h3>
<?php       $random = rand(1, 10); ?>
            <ul class="p-10 bcolor-0 b-3">
<?php           for($i=1; $i <= 10; $i++){ ?>
                    <li class="montserrat color-0 fs-1-6"><?php echo $i . ' x ' . $random . ' = ' . ($i * $random) ?></li>
<?php           } ?>    
        </section>

        <!-- Block Tables choisies via checkboxes -->
        <section id="tables-checks" class="bg-1 w33p p-10 flex f-wrap j-center ac-f-start">
            <h3 class="txt-center h40 lh40 montserrat bg-0 color-1 fs-2 mb-10 w100p">Choix par checkboxes</h3>
            <form id="form-checks" name="form-checks" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                <div class="flex f-wrap space-between">
<?php               for($i=1; $i <= 10; $i++){ ?>
                        <input type="checkbox" name="checkTable[]" id="check-<?php echo $i; ?>" class="checkbox" value="<?php echo $i ?>">
                        <label for="check-<?php echo $i ?>" class="montserrat fs-1-4 w33p mb-10 color-0">
                            <div><i class="fs-1-6 fa fa-check"></i></div>Table des <?php echo $i; ?>
                        </label>
<?php               } ?>
                </div>
                <button type="submit" id="submit-checks" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-checks">Valider</button>
            </form>
            <div class="mt-10 flex w100p f-wrap space-between" id="block-reponse-checks"></div>
        </section>

        <!-- Block Table choisie via liste déroulante -->
        <section id="table-select" class="bg-1 w33p p-10 flex f-wrap j-center ac-f-start">
            <h3 class="txt-center h40 lh40 montserrat bg-0 color-1 fs-2 mb-10 w100p">Choix par select</h3>
            <form id="form-select" name="form-select" class="w100p" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                <select name="select-table" id="select-table" class="w100p p-10 b-2 bcolor-0 bg-1 color-0 montserrat fs-1-4 mb-10">
                    <option value="">Sélectionnez</option>
<?php               for($i=1; $i <= 10; $i++){ ?>
                        <option value="<?php echo $i ?>">Table des <?php echo $i; ?></option>
<?php               } ?>
                </select>
                <button type="submit" id="submit-select" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-select">Valider</button>
            </form>
            <div class="mt-10 flex w100p f-wrap j-center" id="block-reponse-select"></div>
        </section>

        <!-- Block calcul mental -->
        <section id="table-calcul" class="bg-1 w100p mt-10 p-10 flex f-wrap j-center ac-f-start">
            <h3 class="txt-center h40 lh40 montserrat bg-0 color-1 fs-2 mb-10 w100p">Calcul mental</h3>
            <div class="w100p mb-30">
                <form id="form-select-calcul" name="form-select-calcul" class="w33p center" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <select name="select-table-calcul" id="select-table-calcul" class="w100p p-10 b-2 bcolor-0 bg-1 color-0 montserrat fs-1-4 mb-10">
                        <option value="">Sélectionnez</option>
<?php                   for($i=1; $i <= 10; $i++){ ?>
                            <option value="<?php echo $i ?>">Table des <?php echo $i; ?></option>
<?php                   } ?>                        
                    </select>
                    <button type="submit" id="submit-select-calcul" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-select-calcul">Choisir</button>
                </form>
            </div>
            <div class="w100p">
                <div id="calcul"></div>
                <form id="form-response-calcul" name="form-response-calcul" class="w33p center" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                    <input type="text" id="response-calcul" name="response-calcul" class="w100p p-10 b-2 bcolor-0 montserrat fs-1-4 mb-10" value="">
                    <button type="submit" id="submit-response-calcul" class="bg-0 no-border p-10 pointer w100p color-1 fs-1-6 montserrat" name="submit-response-calcul">Répondre</button>
                </form>
                <div id="block-reponse-calcul"></div>
            </div>
        </section>
    </main>
    <footer class="bg-0 h100 w100p txt-center lh100">
        <p class="montserrat fs-3 color-1">@Khylick - 2018</p>
    </footer>
    <script src="./js/script.js"></script>
</body>
</html>