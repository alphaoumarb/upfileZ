/*Fonction construction d'objet*/
function Sprite (filename, left, top){
    this._node = document.createElement("img");
    this._node.src = filename;
    this._node.style.position = "absolute";
    document.body.appendChild(this._node);

    Object.defineProperty(this, "left", {
        get: function() {
            return this._left;
        },
        set: function(value){
            this._left = value;
            this._node.style.left = this._left + "px";
        }
    } );

    Object.defineProperty(this, "top", {
        get: function() {
            return this._top;
        },
        set: function(value){
            this._top = value;
            this._node.style.top = this._top + "px";
        }
    } );

    Object.defineProperty(this, "display", {
        get: function() {
            return this._node.style.display;
        },
        set: function(value){
            this._node.style.display = value;
        }
    } );

    this.left = left;
    this.top = top;
}

Sprite.prototype.startAnimation = function(fct, interval) {
    if (this._clock) window.clearInterval(this._clock);
    var _this = this;
    this._clock = window.setInterval(function() { /* this._clock = identifiant d'interval*/
        fct (_this);
    }, interval );  
}

Sprite.prototype.stopAnimation = function(){
    window.clearInterval(this._clock);
}

/*Gestion des collisions*/
Sprite.prototype.checkCollision = function(other){

    return ! ( (this.top + this._node.height < other.top) ||
                this.top > (other.top + other._node.height) ||
                (this.left + this._node.width < other.left) ||
                this.left > (other.left + other._node.width)
            );
}

var ennemi1 = new Sprite("images/f15.png", 300, 50);
var ennemi2 = new Sprite("images/f15.png", 500, 200);
var ennemi3 = new Sprite("images/f15.png", 700, 450);
var ennemi4 = new Sprite("images/f15.png", 900, 600);
var ennemi5 = new Sprite("images/f15.png", 1100, 600);

/*Ordre des sprites = position (~ z-index)*/
var missile = new Sprite("images/missile.png", 0, 0);
missile.display = "none";

var vaisseau = new Sprite("images/su27.png", 740, 700);

document.addEventListener('keydown', moveVaisseau);

/*Fonction Déplacer*/
function moveVaisseau(e){
    var key = e.keyCode;
    if (key == 37){         /*Déplacement du vaisseau -gauche (flèche gauche)*/
        vaisseau.left -= 10;
    }
    else if (key == 39){    /*Déplacement du vaisseau -droite (flèche droite)*/
        vaisseau.left += 10;
    }
    /*Vérification horizontale (ne pas dépasser le cadre)*/
    if (vaisseau.left < 0){
        vaisseau.left = 0;
    }
    
    if (vaisseau.left > document.body.clientWidth - vaisseau._node.width) {
        vaisseau.left = document.body.clientWidth - vaisseau._node.width;
    }
    /*Tirer un missile (barre Espace)*/
    if (key == 32){ 
        if (missile.display == "none"){  /*Autorise qu'un seul missile /écran */
            missile.display = "block";
            /*Aligner missile par rapport au vaisseau, /2 pour centrer*/
            missile.left = vaisseau.left + (vaisseau._node.width - missile._node.width) / 2;
            missile.top = vaisseau.top;
            missile.startAnimation(moveMissile, 20); /*Invoque la fonctionne périodiquement - */
        }
    }
    /*Tir ennemi TEST*/
    if (key == 13){
        if (missile.display == "none"){  /*Autorise qu'un seul missile /écran */
            missile.display = "block";
        missile.left = ennemi1.left + (ennemi1._node.width - missile._node.width) / 2;
        missile.top = ennemi1.top;
        missile.startAnimation(moveMissile, 20); /*Invoque la fonctionne périodiquement - */
        }
    }
}    


var NbEssais = 0;

function moveMissile(missile){

    NbEssais++;
    localStorage.setItem("NbEssais", NbEssais++);

    missile.top -= 30;
    if (missile.top < -40){
        missile.stopAnimation(); /*Arrête la fonction périodique moveMissile*/
        missile.display = "none"; /*Cache le missile*/
    }

    for( var i=1; i<=5; i++){
        var ennemi = window["ennemi"+i];
        if (ennemi.display == "none") continue;/*Ne test pas la collision sur les ennemis touchés*/
        if (missile.checkCollision(ennemi)){
            document.getElementById('coup').value = NbEssais;
            missile.stopAnimation();/*Arrête l'animation*/
            missile.display = "none";/*Cache l'objet*/
            ennemi.stopAnimation();
            ennemi.display = "none";
        }
    }
}

function moveEnnemiToLeft(ennemi){
    ennemi.left -= 3;

    if (ennemi.left <= 0){
        ennemi.top += 50;
        ennemi.startAnimation(moveEnnemiToRight, 20);
    }
    if (vaisseau.checkCollision(ennemi)){
        missile.stopAnimation();/*Arrête l'animation*/
        missile.display = "none";/*Cache l'objet*/
        ennemi.stopAnimation();
        ennemi.display = "none";
    }  
}

function moveEnnemiToRight(ennemi){
    ennemi.left += 3;

    if (ennemi.left > document.body.clientWidth - ennemi._node.width){
        ennemi.top += 50;
        ennemi.startAnimation(moveEnnemiToLeft, 20);
    }
    if (vaisseau.checkCollision(ennemi)){
        missile.stopAnimation();/*Arrête l'animation*/
        missile.display = "none";/*Cache l'objet*/
        ennemi.stopAnimation();
        ennemi.display = "none";
    }
}



ennemi1.startAnimation(moveEnnemiToRight, 20);
ennemi2.startAnimation(moveEnnemiToRight, 20);
ennemi3.startAnimation(moveEnnemiToRight, 20);
ennemi4.startAnimation(moveEnnemiToRight, 20);
ennemi5.startAnimation(moveEnnemiToRight, 20);
 /*
 function move(e){
var key = e.keyCode;
    switch (key){
        case 37:
            vaisseau.left -= 10;
        case 39:
            vaisseau.left += 10;
    }
}
*/

