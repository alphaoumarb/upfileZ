<nav class="w250 i-block t-left" method="post">
                <ul>
                    <div class="icon-menu dsp-flex sp-between w80">
                        <li><a href="contact.html"><i class="fas fa-envelope fa-3x"></i></a></li>
                        <li><a href="index.html"><i class="fas fa-home fa-3x"></i></a></li>
                    </div>
                    <li><a class="border-anim" href="com.html" title="Commentaire">!--</a></li>
                    <li><a class="border-anim" href="a.html" title="A">A</a></li>
                    <li><a class="border-anim" href="body.html" title="Body">Body</a></li>
                    <li><a class="border-anim" href="div.html" title="Div">Div</a></li>
                    <li><a class="border-anim" href="head.html" title="Head">Head</a></li>
                    <li><a class="border-anim" href="img.html" title="Image">Img</a></li> 
                    <li><a class="border-anim" href="li.html" title="Li">LI</a></li> 
                    <li><a class="border-anim" href="link.html" title="Link">Link</a></li> 
                    <li><a class="border-anim" href="meta.html" title="Meta">Meta</a></li> 
                    <li><a class="border-anim" href="p.html" title="P">P</a></li>
                    <li><a class="border-anim" href="select.html" title="Select">Select</a></li>
                    <li><a class="border-anim" href="table.html" title="Table">Table</a></li>
                    <li><a class="border-anim" href="td.html" title="Td">TD</a></li>
                    <li><a class="border-anim" href="textarea.html" title="Textarea">Textarea</a></li>
                    <li><a class="border-anim" href="title.html" title="Titre">Title</a></li> 
                    <li><a class="border-anim" href="ul.html" title="Ul">UL</a></li>
                    </ul>  
            </nav>