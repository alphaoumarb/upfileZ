<?php

namespace TheCodingMachine\Mail\Template;

interface MailTemplateException
{
}
